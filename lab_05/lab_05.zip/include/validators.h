#ifndef VALIDATORS_H
#define VALIDATORS_H
#include <stdbool.h>

bool validate_time(const char *str);

#endif //VALIDATORS_H
