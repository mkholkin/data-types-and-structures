#ifndef VALIDATORS_H
#define VALIDATORS_H
#include <stdbool.h>

bool size_validator(const char *str);

#endif //VALIDATORS_H
