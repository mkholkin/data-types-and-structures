#ifndef TIME_H
#define TIME_H

#include <time.h>

typedef long long nsec_t;

nsec_t nanoseconds_now(void);

#endif //TIME_H
