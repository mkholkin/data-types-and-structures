#ifndef UTILS_H
#define UTILS_H
#include <stddef.h>

int is_in(const void *array, size_t el_size, size_t array_size, const void *target);

#endif //UTILS_H
