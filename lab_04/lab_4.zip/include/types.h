#ifndef LAB_04_TYPES_H
#define LAB_04_TYPES_H

#include <stdint.h>

typedef uintptr_t item_t;

#endif //LAB_04_TYPES_H
