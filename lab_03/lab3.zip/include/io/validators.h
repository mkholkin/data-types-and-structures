#ifndef VALIDATORS_H
#define VALIDATORS_H

bool size_validator(const char *str);
bool percent_validator(const char *str);

#endif //VALIDATORS_H
