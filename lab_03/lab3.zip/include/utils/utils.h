#ifndef UTILS_H
#define UTILS_H
#include <stddef.h>

void *realloc_zero(void *ptr, size_t size);

#endif //UTILS_H
