#ifndef DEFINES_H
#define DEFINES_H

#define MAX_CARS 5000
#define UINT_MAX_DIGITS 10
#define UL_MAX_DIGITS 20
#define ULL_MAX_DIGITS 20

#define DATA_FILE "../data.bin"
#endif //DEFINES_H
